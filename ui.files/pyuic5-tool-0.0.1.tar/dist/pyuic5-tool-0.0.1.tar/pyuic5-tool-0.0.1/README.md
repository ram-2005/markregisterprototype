# Pyuic5 Tool

A dev tool to make the conversion of .ui PyQt5 Designer's files to .py files easier. just by making an instance
of the included class and calling the convert.ui method at the entry point of your code will convert the files without
having to deal with the cmd or terminal (dev tool to automate the conversion command). Also it helps to separate the
.ui files from the .py files in separate folders.

[Github-Repository](https://github.com/Abdelatief/Pyuic5-Tool)